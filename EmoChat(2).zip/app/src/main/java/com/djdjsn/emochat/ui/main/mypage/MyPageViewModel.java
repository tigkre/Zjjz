package com.djdjsn.emochat.ui.main.mypage;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Transformations;
import androidx.lifecycle.ViewModel;

import com.djdjsn.emochat.data.PreferencesData;
import com.djdjsn.emochat.data.user.User;
import com.djdjsn.emochat.data.user.UserRepository;
import com.djdjsn.emochat.utils.AuthUtils;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class MyPageViewModel extends ViewModel {

    private final UserRepository userRepository;

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final String uid;
    private final LiveData<String> id;
    private final LiveData<String> phone;
    private final LiveData<String> nickname;


    @Inject
    public MyPageViewModel(PreferencesData preferencesData, UserRepository userRepository) {

        this.userRepository = userRepository;

        uid = preferencesData.getCurrentUid();

        LiveData<User> user = userRepository.getUser(uid);
        id = Transformations.map(user, u -> u != null ? u.getId() : null);
        phone = Transformations.map(user, u -> u != null ? u.getPhone() : null);
        nickname = Transformations.map(user, u -> u != null ? u.getNickname() : null);
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public LiveData<String> getId() {
        return id;
    }

    public LiveData<String> getPhone() {
        return phone;
    }

    public LiveData<String> getNickname() {
        return nickname;
    }


    public void onEditNicknameClick() {
        event.setValue(new Event.PromptNewNickname(nickname.getValue()));
    }

    public void onEditNicknameResult(String newNickname) {

        if (newNickname.length() < 2) {
            event.setValue(new Event.ShowGeneralMessage("닉네임은 2글자 이상이어야 합니다"));
            return;
        }

        userRepository.updateNickname(uid, newNickname,
                unused -> event.setValue(new Event.ShowGeneralMessage("닉네임이 수정되었습니다")),
                e -> {
                    event.setValue(new Event.ShowGeneralMessage("네트워크를 확인하세요"));
                    e.printStackTrace();
                });
    }

    public void onDeleteUserClick() {
        event.setValue(new Event.ConfirmUserDelete(id.getValue()));
    }

    public void onDeleteUserResult(String password) {

        String idValue = id.getValue();
        if (idValue == null) {
            return;
        }

        AuthCredential credential = EmailAuthProvider
                .getCredential(AuthUtils.emailize(idValue), password);

        FirebaseUser firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
        if (firebaseUser == null) {
            return;
        }

        // re-authenticate
        firebaseUser.reauthenticate(credential)
                .addOnSuccessListener(unused1 -> {
                    // delete user data
                    userRepository.deleteUser(uid,
                            unused -> {
                                // delete firebase account
                                firebaseUser.delete()
                                        .addOnSuccessListener(unused2 -> {
                                            //
                                            event.setValue(new Event.ShowGeneralMessage("회원탈퇴가 완료되었습니다"));
                                        })
                                        .addOnFailureListener(e -> {
                                            e.printStackTrace();
                                            event.setValue(new Event.ShowGeneralMessage("네트워크를 확인하세요"));
                                        });
                            },
                            e -> {
                                e.printStackTrace();
                                event.setValue(new Event.ShowGeneralMessage("네트워크를 확인하세요"));
                            });
                })
                .addOnFailureListener(e -> {
                    e.printStackTrace();
                    event.setValue(new Event.ShowGeneralMessage("비밀번호를 확인하세요"));
                });
    }


    public static class Event {

        public static class ShowGeneralMessage extends Event {
            public final String message;

            public ShowGeneralMessage(String message) {
                this.message = message;
            }
        }

        public static class PromptNewNickname extends Event {
            public final String oldNickname;

            public PromptNewNickname(String oldNickname) {
                this.oldNickname = oldNickname;
            }
        }

        public static class ConfirmUserDelete extends Event {
            public final String id;

            public ConfirmUserDelete(String id) {
                this.id = id;
            }
        }
    }

}










