package com.djdjsn.emochat.ui.main.mypage;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import com.djdjsn.emochat.R;
import com.djdjsn.emochat.databinding.ConfirmUserDeleteViewBinding;
import com.djdjsn.emochat.databinding.FragmentMyPageBinding;
import com.djdjsn.emochat.databinding.PromptNicknameViewBinding;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class MyPageFragment extends Fragment {

    private FragmentMyPageBinding binding;
    private MyPageViewModel viewModel;
    private NavController navController;


    public MyPageFragment() {
        super(R.layout.fragment_my_page);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentMyPageBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(MyPageViewModel.class);
        navController = Navigation.findNavController(view);

        binding.textViewUserNickname.setOnClickListener(v -> viewModel.onEditNicknameClick());
        binding.buttonDeleteUser.setOnClickListener(v -> viewModel.onDeleteUserClick());

        viewModel.getId().observe(getViewLifecycleOwner(), id -> {
            if (id != null) {
                binding.textViewUserId.setText(id);
            }
        });

        viewModel.getPhone().observe(getViewLifecycleOwner(), phone -> {
            if (phone != null) {
                binding.textViewUserPhone.setText(phone);
            }
        });

        viewModel.getNickname().observe(getViewLifecycleOwner(), nickname -> {
            if (nickname != null) {
                binding.textViewUserNickname.setText(nickname);
            }
        });

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof MyPageViewModel.Event.ShowGeneralMessage) {
                String message = ((MyPageViewModel.Event.ShowGeneralMessage) event).message;
                Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show();
            } else if (event instanceof MyPageViewModel.Event.PromptNewNickname) {
                String oldNickname = ((MyPageViewModel.Event.PromptNewNickname) event).oldNickname;
                showPromptNicknameDialog(oldNickname);
            } else if (event instanceof MyPageViewModel.Event.ConfirmUserDelete) {
                String id = ((MyPageViewModel.Event.ConfirmUserDelete) event).id;
                showConfirmUserDeleteDialog(id);
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    private void showPromptNicknameDialog(String oldNickname) {

        PromptNicknameViewBinding binding =
                PromptNicknameViewBinding.inflate(getLayoutInflater(), null, false);

        binding.editTextNickname.setText(oldNickname);
        binding.editTextNickname.selectAll();

        new AlertDialog.Builder(requireContext())
                .setTitle("닉네임 변경")
                .setView(binding.getRoot())
                .setPositiveButton("닉네임 변경", (dialogInterface, i) -> {
                    String newNickname = binding.editTextNickname.getText().toString().trim();
                    viewModel.onEditNicknameResult(newNickname);
                })
                .setNegativeButton("취소", null)
                .show();
    }

    private void showConfirmUserDeleteDialog(String id) {

        ConfirmUserDeleteViewBinding binding =
                ConfirmUserDeleteViewBinding.inflate(getLayoutInflater(), null, false);

        new AlertDialog.Builder(requireContext())
                .setTitle("회원 탈퇴")
                .setView(binding.getRoot())
                .setPositiveButton("회원 탈퇴", (dialogInterface, i) -> {
                    String idConfirmation = binding.editTextPassword.getText().toString().trim();
                    viewModel.onDeleteUserResult(idConfirmation);
                })
                .setNegativeButton("취소", null)
                .show();
    }

}









